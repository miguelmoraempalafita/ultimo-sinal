extends Node2D

# ÚLTIMO SINAL — protótipo 2D mobile
# Tudo é desenhado por código para o projeto ficar leve e não depender de imagens externas.

const WORLD_W := 6200.0
const FLOOR_Y := 590.0
const GRAVITY := 1450.0
const SPEED := 330.0
const JUMP := -650.0

var player := {
    "pos": Vector2(220, 480),
    "vel": Vector2.ZERO,
    "hp": 3,
    "ammo": 18,
    "face": 1.0,
    "ground": false,
    "shoot_cd": 0.0,
    "inv": 0.0
}
var zombies: Array = []
var bullets: Array = []
var particles: Array = []
var camera_x := 0.0
var started := false
var ended := false
var win := false
var message := ""
var message_time := 0.0
var joystick_touch := -1
var joystick_origin := Vector2.ZERO
var joystick := Vector2.ZERO
var touch_ids := {}

var platforms = [
    Rect2(0, FLOOR_Y, 900, 130),
    Rect2(1030, 520, 850, 200),
    Rect2(2010, 470, 760, 250),
    Rect2(2870, 550, 740, 170),
    Rect2(3710, 500, 760, 220),
    Rect2(4560, 570, 1640, 150),
    Rect2(520, 440, 230, 24),
    Rect2(1180, 385, 260, 24),
    Rect2(1610, 455, 170, 24),
    Rect2(2180, 350, 250, 24),
    Rect2(3050, 410, 220, 24),
    Rect2(3890, 360, 230, 24),
    Rect2(4320, 425, 180, 24),
    Rect2(4880, 390, 230, 24)
]

func _ready():
    _spawn_zombies()
    queue_redraw()

func _spawn_zombies():
    zombies = [
        {"pos":Vector2(650,520),"hp":2,"speed":65.0,"type":0},
        {"pos":Vector2(1300,315),"hp":2,"speed":72.0,"type":0},
        {"pos":Vector2(1770,465),"hp":3,"speed":78.0,"type":1},
        {"pos":Vector2(2240,415),"hp":2,"speed":70.0,"type":0},
        {"pos":Vector2(3150,495),"hp":3,"speed":82.0,"type":1},
        {"pos":Vector2(3970,445),"hp":2,"speed":75.0,"type":0},
        {"pos":Vector2(4380,370),"hp":3,"speed":80.0,"type":1},
        {"pos":Vector2(4920,515),"hp":2,"speed":70.0,"type":0},
        {"pos":Vector2(5500,515),"hp":4,"speed":90.0,"type":1}
    ]

func _process(delta):
    if not started:
        queue_redraw()
        return
    if ended:
        queue_redraw()
        return
    _update_game(delta)
    queue_redraw()

func _update_game(delta):
    var axis := Input.get_axis("move_left", "move_right")
    if abs(joystick.x) > 0.12:
        axis = joystick.x
    player.vel.x = move_toward(player.vel.x, axis * SPEED, 1800.0 * delta)
    if abs(axis) > 0.1:
        player.face = sign(axis)

    if (Input.is_action_just_pressed("jump") or _touch_jump) and player.ground:
        player.vel.y = JUMP
        player.ground = false
    _touch_jump = false

    player.vel.y += GRAVITY * delta
    player.pos += player.vel * delta
    player.pos.x = clamp(player.pos.x, 20.0, WORLD_W - 40.0)

    player.ground = false
    var pr := Rect2(player.pos.x - 18, player.pos.y - 52, 36, 52)
    for p in platforms:
        if pr.end.y >= p.position.y and pr.end.y - player.vel.y * delta <= p.position.y + 12 and pr.end.x > p.position.x and pr.position.x < p.end.x and player.vel.y >= 0:
            player.pos.y = p.position.y
            player.vel.y = 0
            player.ground = true

    if player.pos.y > 800:
        _hurt(3)

    player.inv = max(0.0, player.inv - delta)
    player.shoot_cd = max(0.0, player.shoot_cd - delta)
    if Input.is_action_pressed("shoot") or _touch_shoot:
        _shoot()
    _touch_shoot = false

    for b in bullets:
        b.pos += b.vel * delta
        b.life -= delta
    bullets = bullets.filter(func(b): return b.life > 0 and b.pos.x > camera_x - 100 and b.pos.x < camera_x + 1500)

    for z in zombies:
        var dx = player.pos.x - z.pos.x
        if abs(dx) < 650:
            z.pos.x += sign(dx) * z.speed * delta
        z.pos.y += GRAVITY * delta
        var zr := Rect2(z.pos.x - 20, z.pos.y - 58, 40, 58)
        for p in platforms:
            if zr.end.y >= p.position.y and zr.end.y - GRAVITY * delta <= p.position.y + 12 and zr.end.x > p.position.x and zr.position.x < p.end.x:
                z.pos.y = p.position.y
        if Rect2(player.pos.x-17,player.pos.y-50,34,50).intersects(zr):
            _hurt(1)

    for b in bullets:
        for z in zombies:
            if Rect2(z.pos.x-20,z.pos.y-58,40,58).has_point(b.pos):
                z.hp -= 1
                b.life = 0
                _burst(z.pos, 8)
    zombies = zombies.filter(func(z): return z.hp > 0)

    for part in particles:
        part.pos += part.vel * delta
        part.vel.y += 600 * delta
        part.life -= delta
    particles = particles.filter(func(p): return p.life > 0)

    camera_x = lerp(camera_x, player.pos.x - 360.0, 0.09)
    camera_x = clamp(camera_x, 0.0, WORLD_W - 1280.0)

    if player.pos.x > 5900:
        win = true
        ended = true
        message = "A transmissão respondeu: \"Leo? Você demorou.\""
        message_time = 999.0

var _touch_jump := false
var _touch_shoot := false

func _shoot():
    if player.shoot_cd > 0 or player.ammo <= 0:
        return
    player.ammo -= 1
    player.shoot_cd = 0.22
    bullets.append({"pos":player.pos + Vector2(player.face*25,-31),"vel":Vector2(player.face*1000,-15),"life":1.1})
    _burst(player.pos + Vector2(player.face*30,-31), 6)

func _hurt(amount):
    if player.inv > 0 or ended:
        return
    player.hp -= amount
    player.inv = 1.0
    player.vel.x = -player.face * 260
    _burst(player.pos, 12)
    if player.hp <= 0:
        ended = true
        win = false
        message = "Os passos chegaram antes de você. O rádio continuou transmitindo sozinho."

func _burst(pos:Vector2, amount:int):
    for i in amount:
        particles.append({"pos":pos,"vel":Vector2(randf_range(-180,180),randf_range(-260,80)),"life":randf_range(.25,.7)})

func _input(event):
    if event is InputEventScreenTouch:
        if event.pressed:
            touch_ids[event.index] = event.position
            if not started:
                if Rect2(430, 500, 420, 110).has_point(event.position):
                    started = true
                return
            if event.position.x < 420:
                joystick_touch = event.index
                joystick_origin = event.position
                joystick = Vector2.ZERO
            elif event.position.x > 1050 and event.position.y > 510:
                _touch_shoot = true
            elif event.position.x > 820 and event.position.y > 500:
                _touch_jump = true
        else:
            if event.index == joystick_touch:
                joystick_touch = -1
                joystick = Vector2.ZERO
            touch_ids.erase(event.index)
    elif event is InputEventScreenDrag and event.index == joystick_touch:
        var d = event.position - joystick_origin
        joystick = d.limit_length(85.0) / 85.0

func _draw():
    # world
    draw_rect(Rect2(0,0,1280,720), Color("#070a0f"))
    if not started:
        _draw_title()
        return

    draw_set_transform(Vector2(-camera_x,0))
    _draw_background()
    for p in platforms:
        draw_rect(p, Color("#252b30"))
        draw_rect(Rect2(p.position, Vector2(p.size.x,5)), Color("#5c625f"))
        for x in range(int(p.position.x)+20, int(p.end.x)-10, 60):
            draw_line(Vector2(x,p.position.y+14),Vector2(x+18,p.position.y+14),Color("#343b3d"),2)

    # radio tower
    draw_line(Vector2(5980,570),Vector2(6040,230),Color("#555d60"),7)
    draw_line(Vector2(6040,230),Vector2(6100,570),Color("#555d60"),7)
    draw_line(Vector2(6000,420),Vector2(6080,420),Color("#555d60"),4)
    draw_circle(Vector2(6040,205),11,Color("#b73b3b"))

    for b in bullets:
        draw_circle(b.pos,4,Color("#fff3bb"))

    for z in zombies:
        _draw_zombie(z)

    if player.inv <= 0 or int(player.inv*15)%2 == 0:
        _draw_player()

    for part in particles:
        draw_circle(part.pos,3,Color(0.8,0.75,0.65,clamp(part.life*2,0,1)))

    draw_set_transform(Vector2.ZERO)
    _draw_hud()
    _draw_controls()

    if ended:
        _draw_end()

func _draw_background():
    # layered city
    for layer in range(3):
        var col = [Color("#0b1016"),Color("#10161c"),Color("#151b20")][layer]
        var step = 170 - layer*25
        for x in range(-200, int(WORLD_W)+300, step):
            var h = 100 + ((x*7 + layer*91) % 180)
            draw_rect(Rect2(x, FLOOR_Y-h, step-18, h), col)
    for x in range(-100, int(WORLD_W), 260):
        draw_circle(Vector2(x,170),45,Color(0.75,0.8,0.76,0.06))
    draw_circle(Vector2(800,105),42,Color("#c9cec2"))
    draw_circle(Vector2(820,92),42,Color("#080d13"))
    # fog
    for i in range(7):
        draw_circle(Vector2(camera_x+150+i*210,470+(i%2)*30),90,Color(0.45,0.5,0.52,0.035))

func _draw_player():
    var x=player.pos.x
    var y=player.pos.y
    var d=player.face
    draw_ellipse(Vector2(x,y-2),Vector2(24,7),Color(0,0,0,0.35))
    draw_rect(Rect2(x-14,y-42,28,28),Color("#4d5557"))
    draw_rect(Rect2(x-13,y-25,11,25),Color("#252b30"))
    draw_rect(Rect2(x+2,y-25,11,25),Color("#252b30"))
    draw_rect(Rect2(x-17,y-43,34,18),Color("#596064"))
    draw_rect(Rect2(x-12,y-59,24,18),Color("#a98573"))
    draw_circle(Vector2(x,y-61),13,Color("#292424"))
    draw_rect(Rect2(x-14,y-66,28,7),Color("#252122"))
    draw_circle(Vector2(x+d*7,y-58),2,Color("#101010"))
    draw_line(Vector2(x+d*10,y-34),Vector2(x+d*30,y-25),Color("#a98c7b"),6)
    draw_rect(Rect2(x+d*27-5,y-29,12,7),Color("#d1d1c8"))
    draw_rect(Rect2(x-20,y-39,7,20),Color("#303734"))

func _draw_zombie(z):
    var x=z.pos.x
    var y=z.pos.y
    var c=Color("#6c756b") if z.type==0 else Color("#806a5e")
    draw_ellipse(Vector2(x,y-2),Vector2(25,7),Color(0,0,0,.35))
    draw_rect(Rect2(x-19,y-43,38,43),c)
    draw_circle(Vector2(x,y-52),18,c.lightened(.08))
    draw_circle(Vector2(x-7,y-55),3,Color("#151616"))
    draw_circle(Vector2(x+8,y-55),3,Color("#151616"))
    draw_line(Vector2(x-16,y-27),Vector2(x-32,y-8),c,7)
    draw_line(Vector2(x+16,y-27),Vector2(x+32,y-8),c,7)
    if z.type==1:
        draw_circle(Vector2(x,y-38),5,Color("#8b3434"))

func draw_ellipse(center:Vector2, radius:Vector2, color:Color):
    var pts=PackedVector2Array()
    for i in range(24):
        var a=TAU*i/24.0
        pts.append(center+Vector2(cos(a)*radius.x,sin(a)*radius.y))
    draw_colored_polygon(pts,color)

func _draw_title():
    draw_rect(Rect2(0,0,1280,720),Color("#05070b"))
    draw_circle(Vector2(960,120),60,Color("#cbd0c5"))
    draw_circle(Vector2(985,100),60,Color("#05070b"))
    draw_string(ThemeDB.fallback_font,Vector2(100,170),"ÚLTIMO SINAL",HORIZONTAL_ALIGNMENT_LEFT,700,64,Color("#e4e4df"))
    draw_string(ThemeDB.fallback_font,Vector2(104,220),"UM SURVIVAL HORROR 2D",HORIZONTAL_ALIGNMENT_LEFT,600,24,Color("#8c9497"))
    draw_string(ThemeDB.fallback_font,Vector2(104,285),"Leo acordou no laboratório municipal.",HORIZONTAL_ALIGNMENT_LEFT,900,28,Color("#c0c0bb"))
    draw_string(ThemeDB.fallback_font,Vector2(104,325),"Uma transmissão misteriosa é a única esperança.",HORIZONTAL_ALIGNMENT_LEFT,900,28,Color("#c0c0bb"))
    draw_rect(Rect2(430,500,420,110),Color("#20252a"))
    draw_string(ThemeDB.fallback_font,Vector2(485,567),"TOQUE PARA COMEÇAR",HORIZONTAL_ALIGNMENT_LEFT,340,30,Color("#f0f0e8"))

func _draw_hud():
    draw_rect(Rect2(18,18,380,64),Color(0,0,0,.48))
    draw_string(ThemeDB.fallback_font,Vector2(35,47),"LEO",HORIZONTAL_ALIGNMENT_LEFT,80,25,Color("#e8e8df"))
    draw_string(ThemeDB.fallback_font,Vector2(35,70),"VIDA: "+"♥".repeat(player.hp)+"♡".repeat(3-player.hp),HORIZONTAL_ALIGNMENT_LEFT,200,19,Color("#d96b68"))
    draw_string(ThemeDB.fallback_font,Vector2(215,55),"MUNIÇÃO: %02d" % player.ammo,HORIZONTAL_ALIGNMENT_LEFT,150,19,Color("#ddd7b7"))
    draw_string(ThemeDB.fallback_font,Vector2(910,45),"CHEGUE À TORRE",HORIZONTAL_ALIGNMENT_LEFT,300,21,Color("#c4c9c8"))

func _draw_controls():
    # joystick
    draw_circle(Vector2(120,610),78,Color(1,1,1,.16))
    draw_circle(Vector2(120,610)+joystick*45,35,Color(1,1,1,.30))
    # jump / shoot
    draw_circle(Vector2(1080,610),58,Color(1,1,1,.14))
    draw_string(ThemeDB.fallback_font,Vector2(1055,620),"PULO",HORIZONTAL_ALIGNMENT_LEFT,100,17,Color("#ddd"))
    draw_circle(Vector2(1180,520),65,Color(0.5,0.12,0.12,.35))
    draw_string(ThemeDB.fallback_font,Vector2(1150,528),"ATIRAR",HORIZONTAL_ALIGNMENT_LEFT,100,17,Color("#eee"))

func _draw_end():
    draw_rect(Rect2(240,170,800,380),Color(0,0,0,.88))
    var title="VOCÊ SOBREVIVEU" if win else "FIM DA LINHA"
    draw_string(ThemeDB.fallback_font,Vector2(320,260),title,HORIZONTAL_ALIGNMENT_LEFT,650,44,Color("#eee"))
    draw_string(ThemeDB.fallback_font,Vector2(320,325),message,HORIZONTAL_ALIGNMENT_LEFT,650,23,Color("#bfc2c1"))
    draw_string(ThemeDB.fallback_font,Vector2(400,465),"FECHAR E REINICIAR",HORIZONTAL_ALIGNMENT_LEFT,500,25,Color("#ddd"))
